﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Custom
{
    public class Graph
    {
        int v;
        List<int>[] nodes;
        /// <summary>
        /// Denna metod skapar en array och skapar även en lista för varje plats i arrayn.
        /// </summary>
        /// <param name="v"></param>
        public Graph(int v)
        {
            this.v = v;
            nodes = new List<int>[v];
            for (int i = 0; i < v; i++)
            {
                nodes[i] = new List<int>();
            }

        }
        /// <summary>
        /// Denna metod kopierar en graf och hur dennas edges ser ut.
        /// </summary>
        /// <param name="g"></param>
        public Graph(Graph g)
        {
            this.v = g.v;
            nodes = new List<int>[v];
            for (int i = 0; i < v; i++)
            {
                nodes[i] = new List<int>();
                for (int j = 0; j < g.nodes[i].Count; j++)
                {
                    nodes[i].Add(g.nodes[i][j]);
                }
            }
        }
        /// <summary>
        /// Denna metod lägger till edges mellan 2 noder
        /// </summary>
        /// <param name="v"></param>
        /// <param name="w"></param>
        public void AddEdge(int v, int w)
        {
            nodes[v].Add(w);
            nodes[w].Add(v);
        }
        public int V()
        {
            return v;
        }

        public int E()
        {
            int edges = 0;
            foreach (var n in nodes)
            {
                edges += n.Count();
            }
            edges /= 2;
            return edges;
        }
        /// <summary>
        /// Denna metod returnerar en lista på närliggande noder till en viss nod.
        /// </summary>
        /// <param name="v"></param>
        /// <returns></returns>
        public List<int> Adj(int v)
        {
            return nodes[v];
        }
        /// <summary>
        /// Denna metod skriver ut alla noder samt deras edges
        /// </summary>
        /// <returns></returns>
        public string SuperString()
        {
            string s = V() + " vertices, " + E() + " edges\n";
            for (int v = 0; v < V(); v++)
            {
                s += v + ": ";
                foreach (var w in this.Adj(v))
                {
                    s += w + " ";
                }
                s += "\n";
            }
            return s;
        }
        /// <summary>
        /// Denna metod tar bort edges mellan två noder
        /// </summary>
        /// <param name="v"></param>
        /// <param name="w"></param>
        public void CutEdges(int v, int w)
        {
            nodes[v].Remove(w);
            nodes[w].Remove(v);
        }

        /// <summary>
        /// Denna metod genomför en BFS sökning från nuvarande position till en "målnod". 
        /// Metoden avslutas när första målnoden hittats.
        /// </summary>
        /// <param name="edgeTo"></param>
        /// <param name="currentNode"></param>
        /// <param name="isPlayer"></param>
        /// <param name="goalNode"></param>
        /// <returns></returns>
        public bool BFS(ref int[] edgeTo, int currentNode, bool isPlayer, ref int goalNode)
        {
            bool[] marked = new bool[81];
            edgeTo = new int[81];
            bool goal = false;
            Queue<int> q = new Queue<int>();
            q.Enqueue(currentNode);
            marked[currentNode] = true;
            while (!goal)
            {
                if (q.Count == 0)
                {
                    return false;
                }

                int v = q.Dequeue();

                foreach (int w in Adj(v))
                {
                    if (!marked[w])
                    {
                        q.Enqueue(w);
                        marked[w] = true;
                        edgeTo[w] = v;

                    }
                    if (isPlayer)
                    {
                        if (w >= 72)
                        {
                            goalNode = w;
                            goal = true;
                        }
                    }
                    else
                    {
                        if (w <= 8)
                        {
                            goalNode = w;
                            goal = true;
                        }
                    }
                }
            }
            return true;
        }
        /// <summary>
        /// Denna metod får information från BFS och börjar ifrån målnoden. Loopar info fram till startnoden.
        /// </summary>
        /// <param name="pos"></param>
        /// <param name="count"></param>
        /// <param name="edgeTo"></param>
        /// <param name="goalNode"></param>
        /// <param name="isPlayer"></param>
        /// <returns></returns>
        public Point ShortestPath(int pos, ref int count, int[] edgeTo, int goalNode, bool isPlayer)
        {
            count = 0;
            int next = 0;
            int parent = goalNode;

            while (parent != pos)
            {
                count++;
                next = parent;
                parent = edgeTo[next];
            }
            
            return Global.NodeToPoint(next);
        }
    }
}
