﻿using Microsoft.Xna.Framework;
using System;
using Custom;
using System.Collections;
using System.Collections.Generic;

class Agent : BaseAgent
{
    int goalNodeSelf, goalNodeOpponent, stepsGoalSelf, stepsGoalOpponent;
    bool[,] hVägg, vVägg;
    Graph g = new Graph(81);
    int[] edgeToSelf, edgeToOpponent;
    Evaluate[,] eValsH, eValsV;
    Evaluate eV, eH;


    [STAThread]
    static void Main()
    {
        Program.Start(new Agent());
    }
    public Agent()
    {
        AddGrapEdges(g);
        hVägg = new bool[9, 8];
        vVägg = new bool[8, 9];

    }
    public override Drag SökNästaDrag(SpelBräde bräde)
    {
        //Så ni kan kolla om systemet fungerar!

        CheckHorisontellt(bräde);
        CheckVertikalt(bräde);

        Spelare jag = bräde.spelare[0];
        Spelare opponent = bräde.spelare[1];
        Point playerPos = jag.position;
        Point opponentPos = opponent.position;
        Drag drag = new Drag();
        Drag dragH = new Drag();
        Drag dragV = new Drag();
        g.BFS(ref edgeToSelf, Global.PointToNode(playerPos), true, ref goalNodeSelf);
        g.BFS(ref edgeToOpponent, Global.PointToNode(opponent.position), false, ref goalNodeOpponent);
        Point p1 = g.ShortestPath(Global.PointToNode(playerPos), ref stepsGoalSelf, edgeToSelf, goalNodeSelf, true);
        g.ShortestPath(Global.PointToNode(opponent.position), ref stepsGoalOpponent, edgeToOpponent, goalNodeOpponent, false);

        eValsH = new Evaluate[4,4];
        eValsV = new Evaluate[4,4];

        for (int i = 0; i < eValsH.GetLength(0); i++)
        {
            for (int j = 0; j < eValsH.GetLength(1); j++)
            {
                drag.typ = Typ.Horisontell;
                Point wPos = new Point(opponentPos.X -1 + i, opponentPos.Y -1 + j);
                eValsH[i, j] = new Evaluate(new Graph(g), playerPos, opponent.position, wPos, drag, edgeToOpponent);
            }
        }
        for (int i = 0; i < eValsV.GetLength(0); i++)
        {
            for (int j = 0; j < eValsV.GetLength(1); j++)
            {
                drag.typ = Typ.Vertikal;
                Point wPos = new Point(opponentPos.X -1 + i, opponentPos.Y -1 + j);
                eValsV[i, j] = new Evaluate(new Graph(g), playerPos, opponent.position, wPos, drag, edgeToOpponent);
            }
        }

        int stepsH = -10;
        int stepsV = -10;

        if (jag.antalVäggar != 0 && stepsGoalOpponent < stepsGoalSelf)
        {
            for (int i = 0; i < eValsV.GetLength(0); i++)
            {
                for (int j = 0; j < eValsV.GetLength(1); j++)
                {
                    if (eValsV[i, j].wallPlaceable)
                    {
                        if (eValsV[i, j].result > stepsV && eValsV[i,j].prio)
                        {
                            eV = eValsV[i, j];
                            stepsV = eValsV[i, j].result;
                            dragV.point = eValsV[i, j].wallPos;
                            dragV.typ = Typ.Vertikal;
                        }
                    }

                }
            }
            for (int i = 0; i < eValsH.GetLength(0); i++)
            {
                for (int j = 0; j < eValsH.GetLength(1); j++)
                {
                    if (eValsH[i, j].wallPlaceable)
                    {
                        if (eValsH[i, j].result > stepsH && eValsH[i,j].prio)
                        {
                            eH = eValsH[i, j];
                            stepsH = eValsH[i, j].result;
                            dragH.point = eValsH[i, j].wallPos;
                            dragH.typ = Typ.Horisontell;
                        }
                    }

                }
            }

            if (eH.opponentSteps >= eV.opponentSteps)
            {

                drag = dragH;
            }

            else
            {
                drag = dragV;
            }
        }
        else
        {
            drag.typ = Typ.Flytta;
            drag.point = p1;
        }
        if (drag.typ == Typ.Flytta)
        {
            drag.point = p1;
        }
        
        return drag;
    }
    /// <summary>
    /// Denna metod tittar ifall spelbrädets info om vertikala väggar har ändrats. Om så är fallet ändrar vi i vår graf också.
    /// </summary>
    /// <param name="bräde"></param>
    private void CheckVertikalt(SpelBräde bräde)
    {
        if (vVägg != bräde.vertikalaVäggar)
        {
            for (int x = 0; x < vVägg.GetLength(0); x++)
            {
                for (int y = 0; y < vVägg.GetLength(1); y++)
                {
                    if (vVägg[x, y] != bräde.vertikalaVäggar[x, y])
                    {
                        vVägg[x, y] = true;
                        Global.VCut(ref g, new Point(x, y));

                    }
                }
            }
        }
    }
    /// <summary>
    /// Denna metod tittar ifall spelbrädets info om horisontella väggar har ändrats. Om så är fallet ändrar vi i vår graf också.
    /// </summary>
    /// <param name="bräde"></param>
    private void CheckHorisontellt(SpelBräde bräde)
    {
        if (hVägg != bräde.horisontellaVäggar)
        {
            for (int x = 0; x < hVägg.GetLength(0); x++)
            {
                for (int y = 0; y < hVägg.GetLength(1); y++)
                {
                    if (hVägg[x, y] != bräde.horisontellaVäggar[x, y])
                    {

                        hVägg[x, y] = true;
                        Global.HCut(ref g, new Point(x, y));
                       
                    }
                }
            }
        }
    }

    public override Drag GörOmDrag(SpelBräde bräde, Drag drag)
    {
        //Om draget ni försökte göra var felaktigt så kommer ni hit
        System.Diagnostics.Debugger.Break();    //Brytpunkt
        return SökNästaDrag(bräde);
    }
    /// <summary>
    /// Denna metod lägger till edges mellan noder.
    /// </summary>
    /// <param name="g"></param>
    void AddGrapEdges(Graph g)
    {
        int squareRoot = (int)Math.Sqrt(g.V());
        
        for (int i = 0; i < g.V() - 1; i++)
        {
            if ((i + 1) % squareRoot == 0 && i != 0)
            {
                continue;
            }
            g.AddEdge(i, i + 1);
        }
        for (int i = 0; i < g.V() - squareRoot; i++)
        {

            g.AddEdge(i, i + squareRoot);
        }
    }
}