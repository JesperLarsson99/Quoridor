﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Custom
{
    public static class Global
    {
        public static Point NodeToPoint(int w)
        {
            Point p;
            p.X = w % 9;
            p.Y = w / 9;
            return p;
        }

        public static int PointToNode(Point p)
        {
            return (p.Y * 9) + p.X; 
        }

        public static void HCut(ref Graph g, Point p)
        {
            int node = Global.PointToNode(p);
            g.CutEdges(node, node + 9);
            Console.WriteLine("Hcut mellan " + node +" "+ node+9 + " i " + g.ToString());
        }
        public static void HorisontellCut(ref Graph g, Point p)
        {
            int node = Global.PointToNode(p);
            g.CutEdges(node, node + 9);
            Console.WriteLine("Hcut2 mellan " + node +" "+ node+9 + " i " + g.ToString());
        }

        public static void VCut(ref Graph g, Point p)
        {
            int node = Global.PointToNode(p);
            g.CutEdges(node, node + 1);
        }
    }
}
