﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Custom;

namespace Custom
{
    class Evaluate
    {
        Graph g;
        Point selfPos, opponentPos;
        public Point wallPos;
        int selfSteps, selfGoalNode, opponentGoalNode;
        public int result, opponentSteps;
        Drag drag;
        public bool wallPlaceable, prio;
        int[] selfEdgeTo, opponentEdgeTo;
        public int[] tempEdgeToOpponent;

        public Evaluate(Graph g, Point selfPos, Point opponentPos, Point wallPos, Drag drag, int[] tempEdgeToOpponent)
        {
            this.g = g;
            this.selfPos = selfPos;
            this.opponentPos = opponentPos;
            this.wallPos = wallPos;
            this.drag = drag;
            this.tempEdgeToOpponent = tempEdgeToOpponent;
            prio = false;

            if (wallPlaceable = TestIfWallIsPlaceable())
            {
                bool selfBFS = g.BFS(ref selfEdgeTo, Global.PointToNode(selfPos), true, ref selfGoalNode);
                bool opponentBFS = g.BFS(ref opponentEdgeTo, Global.PointToNode(opponentPos), false, ref opponentGoalNode);
                if (selfBFS && opponentBFS)
                {
                    g.ShortestPath(Global.PointToNode(selfPos), ref selfSteps, selfEdgeTo, selfGoalNode, true);
                    g.ShortestPath(Global.PointToNode(opponentPos), ref opponentSteps, opponentEdgeTo, opponentGoalNode, false);
                    result = opponentSteps - selfSteps;
                    if (tempEdgeToOpponent != opponentEdgeTo)
                    {
                        prio = true;
                    }
                }
                else
                {
                    wallPlaceable = false;
                }
            }
        }

        /// <summary>
        /// Denna metod tittar ifall väggpositionen är innanför ramarna i spelet.
        /// </summary>
        /// <returns></returns>
        private bool TestIfWallIsPlaceable()
        {
            if (drag.typ == Typ.Horisontell && wallPos.X >= 0 && wallPos.X < 8 && wallPos.Y >= 0 && wallPos.Y < 8)
            {
                if (IsCutOk(wallPos, drag))
                {
                    int x = Global.PointToNode(wallPos);
                    int y = x + 9;
                    int z = x + 1;
                    int w = z + 9;
                    g.CutEdges(x, y);
                    g.CutEdges(z, w);

                    return true;
                }
            }
            else if (drag.typ == Typ.Vertikal && wallPos.X >= 0 && wallPos.X < 8 && wallPos.Y >= 0 && wallPos.Y < 8)
            {
                if (IsCutOk(wallPos, drag))
                {
                    int x = Global.PointToNode(wallPos);
                    int y = x + 1;
                    int z = x + 9;
                    int w = z + 1;
                    g.CutEdges(x, y);
                    g.CutEdges(z, w);
                    
                    return true;
                }
            }
            return false;
        }
        /// <summary>
        /// Denna metod tittar ifall där redan ligger en vägg på denna plats.
        /// </summary>
        /// <param name="p"></param>
        /// <param name="drag"></param>
        /// <returns></returns>
        private bool IsCutOk(Point p, Drag drag)
        {
            if (drag.typ == Typ.Horisontell)
            {
                int x = Global.PointToNode(p);
                int y = x + 9;
                int z = x + 1;
                int w = z + 9;

                for (int i = 0; i < g.Adj(x).Count; i++)
                {
                    if (g.Adj(x)[i] == y)
                    {
                        for (int j = 0; j < g.Adj(z).Count; j++)
                        {
                            if (g.Adj(z)[j] == w)
                            {
                                return true;
                            }
                        }
                    }
                }
            }
            else if (drag.typ == Typ.Vertikal)
            {
                int x = Global.PointToNode(p);
                int y = x + 1;
                int z = x + 9;
                int w = z + 1;

                for (int i = 0; i < g.Adj(x).Count; i++)
                {
                    if (g.Adj(x)[i] == y)
                    {
                        for (int j = 0; j < g.Adj(z).Count; j++)
                        {
                            if (g.Adj(z)[j] == w)
                            {
                                return true;
                            }
                        }
                    }
                }
            }

            return false;
        }
    }
}
